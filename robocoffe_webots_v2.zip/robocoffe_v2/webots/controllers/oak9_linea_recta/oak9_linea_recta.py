"""
OAK9 + RoboCoffe module -- resolved-rate (Jacobian inversion) control of point o5.
LabDST ITESO. Same control law as the physical robot (real/oak9_linea_recta_real.py).

Task: o5 goes in a straight line from A=(0,0) to B=(DIST,0) with the tracking controller.

controllerArgs (set in the .wbt):
    caso=<label>     name of the run -> log_<label>.csv   (e.g. sinCafe / conCafe)
    dist=<metres>    distance A->B for o5                  (default 1.0)
    acc=<rad/s^2>    wheel acceleration limit              (default A_RUEDA)
    quit             close Webots when the run ends        (batch use only)

Feedback (as on the real robot): wheel encoders for distance, gyro for heading.
Ground truth (Supervisor) is only logged, never fed back.
Logged for the with/without-coffee comparison: true pose, pitch/roll, acceleration
at the cup (accelerometer 'accel_vaso' at the coffee centre of mass).
"""
import csv
import math
import os
import sys

from controller import Supervisor

# ------------------------------------------------------------------ parameters
RHO = 0.034        # wheel radius [m]          (o_1.STL)
L = 0.1663         # wheel separation [m]       (ficha tecnica, team decision)
R15 = 0.100        # o1 -> o5 [m]
K = R15 * RHO / L

KP = 1.0           # [1/s]
WMAX = 3.0         # [rad/s] same saturation as the physical robot script
A_RUEDA = 10.0     # [rad/s^2] wheel acceleration limit (Webots Motor.setAcceleration).
                   # Real value <POR MEDIR>: oak9lib robot.encoder.kinematics() -> deg/s^2
TOL = 0.010        # [m]
T_MAX = 40.0       # [s]
T_SETTLE = 2.0     # [s] keep logging after stopping (pitch oscillation after braking)

args = dict(a.split("=", 1) if "=" in a else (a, "1") for a in sys.argv[1:])
CASO = args.get("caso", "run")
DIST = float(args.get("dist", 1.0))
A_RUEDA = float(args.get("acc", A_RUEDA))
QUIT = "quit" in args
P_GOAL = (DIST, 0.0)


# ------------------------------------------------------------------ model (course slides)
def jacobian(q1):
    c, s, a = math.cos(q1), math.sin(q1), RHO / 2.0
    return ((a * c - K * s, a * c + K * s),
            (a * s + K * c, a * s - K * c))


def jacobian_inv(q1):
    (m11, m12), (m21, m22) = jacobian(q1)
    det = m11 * m22 - m12 * m21          # = -RHO^2*R15/L, never 0
    return ((m22 / det, -m12 / det), (-m21 / det, m11 / det))


def forward_model(q1, w2, w3):
    (m11, m12), (m21, m22) = jacobian(q1)
    return m11 * w2 + m12 * w3, m21 * w2 + m22 * w3, RHO / L * (w2 - w3)


def saturate(w2, w3, wmax):
    m = max(abs(w2), abs(w3))
    return (w2 * wmax / m, w3 * wmax / m) if m > wmax else (w2, w3)


# ------------------------------------------------------------------ devices
robot = Supervisor()
dt_ms = int(robot.getBasicTimeStep())
dt = dt_ms / 1000.0

m_r = robot.getDevice("right_wheel_joint")      # q2 (o2, right, -y)
m_l = robot.getDevice("left_wheel_joint")       # q3 (o3, left, +y)
for m in (m_r, m_l):
    m.setPosition(float("inf"))                 # velocity mode
    m.setVelocity(0.0)
    m.setAcceleration(A_RUEDA)
s_r = robot.getDevice("right_wheel_joint_sensor")
s_l = robot.getDevice("left_wheel_joint_sensor")
gyro = robot.getDevice("gyro")
imu = robot.getDevice("imu")
acc_vaso = robot.getDevice("accel_vaso")
for d in (s_r, s_l, gyro, imu, acc_vaso):
    d.enable(dt_ms)
node = robot.getSelf()


def true_state():
    p = node.getPosition()
    R = node.getOrientation()
    q1 = math.atan2(R[3], R[0])
    pitch = math.asin(max(-1.0, min(1.0, -R[6])))     # rotation about y (nose down > 0)
    roll = math.atan2(R[7], R[8])
    return p[0] + R15 * R[0], p[1] + R15 * R[3], q1, pitch, roll


robot.step(dt_ms)
phi2_prev, phi3_prev = s_r.getValue(), s_l.getValue()
x5, y5, q1, _, _ = true_state()
x1, y1 = x5 - R15 * math.cos(q1), y5 - R15 * math.sin(q1)
q1_odo = q1
xm, ym, qm = x5, y5, q1

here = os.path.dirname(os.path.abspath(__file__))
log_path = os.path.join(here, f"log_{CASO}.csv")
f = open(log_path, "w", newline="")
w = csv.writer(f)
w.writerow(["t", "fase", "q2dot_cmd", "q3dot_cmd", "x5_model", "y5_model", "q1_model",
            "x5_odo", "y5_odo", "q1_odo", "x5_true", "y5_true", "q1_true",
            "pitch_deg", "roll_deg", "ax_vaso", "ay_vaso", "az_vaso", "err_norm"])
print(f"[OAK9 {CASO}] rho={RHO} L={L} r15={R15} Kp={KP} wmax={WMAX} a_rueda={A_RUEDA} dist={DIST}")

t, w2, w3 = 0.0, 0.0, 0.0
fase, t_stop = "avance", None
while robot.step(dt_ms) != -1:
    t += dt
    # odometry: encoders for distance, gyro for heading
    phi2, phi3 = s_r.getValue(), s_l.getValue()
    d2, d3 = phi2 - phi2_prev, phi3 - phi3_prev
    phi2_prev, phi3_prev = phi2, phi3
    q1_new = q1_odo + gyro.getValues()[2] * dt
    ds, qmid = RHO / 2.0 * (d2 + d3), 0.5 * (q1_odo + q1_new)
    x1 += ds * math.cos(qmid)
    y1 += ds * math.sin(qmid)
    q1_odo = q1_new
    x5o, y5o = x1 + R15 * math.cos(q1_odo), y1 + R15 * math.sin(q1_odo)
    # open-loop model with the commanded speeds
    vx, vy, vq = forward_model(qm, w2, w3)
    xm, ym, qm = xm + vx * dt, ym + vy * dt, qm + vq * dt

    ex, ey = P_GOAL[0] - x5o, P_GOAL[1] - y5o
    e = math.hypot(ex, ey)
    if fase == "avance" and (e < TOL or t > T_MAX):
        fase, t_stop = "frenado", t
        w2 = w3 = 0.0
    if fase == "avance":
        (a11, a12), (a21, a22) = jacobian_inv(q1_odo)
        w2, w3 = saturate(a11 * KP * ex + a12 * KP * ey, a21 * KP * ex + a22 * KP * ey, WMAX)
    m_r.setVelocity(w2)
    m_l.setVelocity(w3)

    xt, yt, qt, pitch, roll = true_state()
    a = acc_vaso.getValues()
    w.writerow([f"{t:.3f}", fase, w2, w3, xm, ym, qm, x5o, y5o, q1_odo, xt, yt, qt,
                math.degrees(pitch), math.degrees(roll), a[0], a[1], a[2], e])

    if fase == "frenado" and t - t_stop >= T_SETTLE:
        print(f"[OAK9 {CASO}] {'goal reached' if e < TOL else 'TIMEOUT'} t_stop={t_stop:.2f}s  "
              f"o5_odo=({x5o:.4f},{y5o:.4f})  o5_true=({xt:.4f},{yt:.4f})  q1={math.degrees(qt):.2f} deg")
        print(f"[OAK9 {CASO}] log -> {log_path}")
        break

f.close()
if QUIT:
    robot.simulationQuit(0)
while robot.step(dt_ms) != -1:
    pass
