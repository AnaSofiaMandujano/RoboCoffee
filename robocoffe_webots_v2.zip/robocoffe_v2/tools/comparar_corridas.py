"""
Compares the with/without-coffee Webots runs and draws the figure for the article.

Usage (project root, after running both worlds in Webots):
    python tools/comparar_corridas.py
Reads   webots/controllers/oak9_linea_recta/log_sinCafe.csv and log_conCafe.csv
Writes  tools/resultados_prueba/comparacion_cafe.png and .pdf, prints a metrics table.
"""
import csv
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOGS = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "webots", "controllers", "oak9_linea_recta")
CASES = [("sinCafe", "Sin café", "#2a78d6", "-"),      # palette slots 1-2, validated (CVD dE 24.7)
         ("conCafe", "Con café", "#eb6834", "--")]     # dashed = secondary encoding (curves overlap)
INK, MUTED, GRID = "#0b0b0b", "#52514e", "#e4e3df"


def load(case):
    rows = list(csv.DictReader(open(os.path.join(LOGS, f"log_{case}.csv"))))
    col = lambda k: np.array([float(r[k]) for r in rows])
    d = {k: col(k) for k in ("t", "x5_true", "y5_true", "x5_model", "pitch_deg", "ax_vaso", "ay_vaso", "err_norm")}
    d["a_h"] = np.hypot(d["ax_vaso"], d["ay_vaso"])
    d["t_stop"] = next(float(r["t"]) for r in rows if r["fase"] == "frenado")
    return d


def main():
    data = {c: load(c) for c, *_ in CASES}
    plt.rcParams.update({"font.size": 8, "axes.edgecolor": MUTED, "axes.labelcolor": INK,
                         "xtick.color": MUTED, "ytick.color": MUTED, "axes.linewidth": 0.6})
    fig, axs = plt.subplots(3, 1, figsize=(3.5, 4.6), sharex=True)   # IEEE single column
    panels = [("x5_true", "$x_5$ real [m]", 1.0),
              ("a_h", "Acel. horizontal\nen el vaso [m/s$^2$]", 1.0),
              ("pitch_deg", "Cabeceo [°]", 1.0)]
    for ax, (key, label, k) in zip(axs, panels):
        for case, name, color, ls in CASES:
            d = data[case]
            ax.plot(d["t"], d[key] * k, ls, color=color, lw=1.6 if ls == "-" else 1.2, label=name)
        ax.set_ylabel(label)
        ax.grid(True, color=GRID, lw=0.5)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
    d0 = data["sinCafe"]
    axs[0].plot(d0["t"], d0["x5_model"], ":", color=MUTED, lw=1.0, label="Modelo (lazo abierto)")
    axs[0].legend(frameon=False, loc="lower right")
    axs[2].set_ylim(-0.5, 0.5)
    axs[-1].set_xlabel("t [s]")
    fig.align_ylabels(axs)
    fig.tight_layout(h_pad=0.6)
    os.makedirs(os.path.join(ROOT, "tools", "resultados_prueba"), exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(ROOT, "tools", "resultados_prueba", f"comparacion_cafe.{ext}"), dpi=300)

    print(f"{'caso':10s} {'t_stop[s]':>9s} {'x5_fin[m]':>9s} {'|y5|max[mm]':>11s} {'pitch max[°]':>12s} {'a_vaso max[m/s2]':>16s}")
    for case, name, *_ in CASES:
        d = data[case]
        print(f"{name:10s} {d['t_stop']:9.2f} {d['x5_true'][-1]:9.4f} {np.abs(d['y5_true']).max() * 1e3:11.2f} "
              f"{np.abs(d['pitch_deg']).max():12.3f} {d['a_h'].max():16.2f}")
    print("figure -> tools/resultados_prueba/comparacion_cafe.png / .pdf")


if __name__ == "__main__":
    main()
