"""
Inertial parameters of the OAK9 + coffee module (RoboCoffe, LabDST).

Why this script exists (see README):
  * SolidWorks overridden masses keep a UNIFORM density, so a single solid "module + cup"
    puts the coffee's mass spread over the whole module -> COM far too low.
  * The module "sin cafe" inertia reported in Data.txt corresponds to the material mass
    (~303 g), not to the overridden 200 g.
  So the inertias are recomputed here from the STL meshes with the MEASURED masses,
  and the coffee is added as a liquid frustum with the parallel-axis theorem.

Usage:  python tools/calc_inercias.py         (run from the project root)
Output: tools/inertials.json  (read by tools/generar_urdf.py)
"""
import json
import os

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MESH = os.path.join(ROOT, "webots", "protos", "meshes")

# ----------------------------------------------------------------- measured data (Data.txt)
M_ROBOT_SIN_MODULO = 1.096   # kg, scale: whole robot WITHOUT module (includes wheels)
M_MODULO = 0.200             # kg, scale: module, empty
M_VASO_CAFE = 0.355          # kg, scale: cup with coffee
M_RUEDA = 0.09806            # kg, SolidWorks (wheel could not be removed to weigh it) <POR MEDIR>
M_BOLA = 0.00418879          # kg, steel sphere r = 5 mm (course example)
RHO_CAFE = 1000.0            # kg/m^3, coffee ~ water

# cup geometry measured on Modulo_conCafe.STL (module frame, metres)
VASO_Z_FONDO, VASO_R_FONDO = 0.0635, 0.029
VASO_Z_BORDE, VASO_R_BORDE = 0.1806, 0.040


def load_stl(path):
    b = open(path, "rb").read()
    n = int.from_bytes(b[80:84], "little")
    dt = np.dtype([("n", "<3f4"), ("v", "<9f4"), ("a", "<u2")])
    return np.frombuffer(b[84:], dtype=dt, count=n)["v"].reshape(-1, 3, 3).astype(float)


def mesh_inertia(tris, mass):
    """Uniform-density solid from a closed mesh: volume, COM, inertia tensor at COM."""
    a, b, c = tris[:, 0], tris[:, 1], tris[:, 2]
    v = np.einsum("ij,ij->i", a, np.cross(b, c)) / 6.0
    vol = v.sum()
    com = ((a + b + c) / 4.0 * v[:, None]).sum(0) / vol
    s = a + b + c
    C = (v[:, None, None] / 20.0 * (np.einsum("ni,nj->nij", a, a) + np.einsum("ni,nj->nij", b, b)
                                     + np.einsum("ni,nj->nij", c, c) + np.einsum("ni,nj->nij", s, s))).sum(0)
    C *= mass / vol
    Cc = C - mass * np.outer(com, com)
    return vol, com, np.trace(Cc) * np.eye(3) - Cc


def shift(I, m, r):
    """Parallel-axis theorem."""
    return I + m * (np.dot(r, r) * np.eye(3) - np.outer(r, r))


def coffee_frustum(mass):
    rad = lambda z: VASO_R_FONDO + (VASO_R_BORDE - VASO_R_FONDO) * (z - VASO_Z_FONDO) / (VASO_Z_BORDE - VASO_Z_FONDO)
    z = np.linspace(VASO_Z_FONDO, VASO_Z_BORDE, 20001)
    dz = z[1] - z[0]
    vol = np.cumsum(np.pi * rad(z) ** 2) * dz
    k = int(np.searchsorted(vol, mass / RHO_CAFE))
    z, r = z[:k], rad(z[:k])
    dm = RHO_CAFE * np.pi * r ** 2 * dz
    zc = (dm * z).sum() / dm.sum()
    ixx = (dm * (r ** 2 / 4 + (z - zc) ** 2)).sum()
    izz = (0.5 * dm * r ** 2).sum()
    return np.array([0.0, 0.0, zc]), np.diag([ixx, ixx, izz]), z[-1], vol[k - 1]


def main():
    out = {}
    # chassis = whole robot minus wheels and balls (the 1096 g were weighed with wheels on)
    m0 = M_ROBOT_SIN_MODULO - 2 * M_RUEDA - 2 * M_BOLA
    _, c0, I0 = mesh_inertia(load_stl(os.path.join(MESH, "o_0.STL")), m0)
    out["base"] = dict(mass=m0, com=c0.tolist(), I=I0.tolist())

    _, c1, I1 = mesh_inertia(load_stl(os.path.join(MESH, "o_1.STL")), M_RUEDA)
    out["rueda"] = dict(mass=M_RUEDA, com=c1.tolist(), I=I1.tolist())

    _, cm, Im = mesh_inertia(load_stl(os.path.join(MESH, "Modulo_sinCafe.STL")), M_MODULO)
    out["modulo_sin"] = dict(mass=M_MODULO, com=cm.tolist(), I=Im.tolist())

    cc, Ic, z_liq, v_liq = coffee_frustum(M_VASO_CAFE)
    M = M_MODULO + M_VASO_CAFE
    C = (M_MODULO * cm + M_VASO_CAFE * cc) / M
    It = shift(Im, M_MODULO, cm - C) + shift(Ic, M_VASO_CAFE, cc - C)
    out["modulo_con"] = dict(mass=M, com=C.tolist(), I=It.tolist())
    out["cafe"] = dict(mass=M_VASO_CAFE, com=cc.tolist(), nivel_z=z_liq, volumen_ml=v_liq * 1e6)

    json.dump(out, open(os.path.join(ROOT, "tools", "inertials.json"), "w"), indent=1)
    for k, v in out.items():
        print(f"{k:11s} m={v['mass']:.4f} kg  com[mm]={np.round(np.array(v['com']) * 1e3, 2)}")
    print(f"coffee level z={z_liq * 1e3:.1f} mm (rim {VASO_Z_BORDE * 1e3:.1f} mm), {v_liq * 1e6:.0f} ml")


if __name__ == "__main__":
    main()
