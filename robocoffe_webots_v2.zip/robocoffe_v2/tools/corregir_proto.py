"""
Applies the hand corrections (course slide 25 + RoboCoffe additions) to the PROTOs that
urdf2webots generates, so they survive every re-export.

Usage (project root, after urdf2webots):
    python tools/corregir_proto.py webots/protos/Oak9_sinCafe.proto webots/protos/Oak9_conCafe.proto

Corrections:
  1. Mesh paths with '/' (urdf2webots on Windows writes '\\').
  2. Header: '# Extracted from <absolute path>' -> tags / keywords / description (Add node).
  3. Default controller 'void' -> 'oak9_linea_recta'; default name -> 'OAK9'.
  4. Sensors with no URDF equivalent: InertialUnit, Gyro, Accelerometer (MPU6050) on the
     chassis, and an Accelerometer 'accel_vaso' at the coffee centre of mass.
  5. contactMaterial 'rueda' on both wheels and 'bola' on both ball transfers, so the world
     can give them different friction (wheel grips, ball ~ frictionless).
  6. castShadows FALSE on the module mesh (>21 845 triangles: Webots cannot cast its shadows).
"""
import re
import sys

Z_VASO = 0.1176   # coffee COM in the module frame (tools/inertials.json -> cafe.com[2])


def fix(path):
    s = open(path, encoding="utf-8").read()
    if "# description: OAK9" in s:
        print(f"{path}: already corrected, nothing to do")
        return
    n0 = s
    tag = "con café" if "conCafe" in path else "sin café"

    # 1. mesh paths
    s = re.sub(r'url "([^"]*)"', lambda m: 'url "%s"' % m.group(1).replace("\\", "/"), s)

    # 2. header
    s = re.sub(r"# Extracted from: .*\n",
               "# tags: nonDeterministic\n"
               "# keywords: robot/wheeled, RoboCoffe, OAK9, LabDST\n"
               f"# description: OAK9 differential robot with the RoboCoffe coffee module ({tag}).\n", s)

    # 3. defaults
    s = re.sub(r'(field\s+SFString\s+name\s+)"[^"]*"', r'\1"OAK9"', s)
    s = re.sub(r'(field\s+SFString\s+controller\s+)"void"', r'\1"oak9_linea_recta"', s)

    # 4a. chassis sensors: insert right after 'children [' of the Robot
    sensors = ('''children [
      InertialUnit {
        name "imu"
      }
      Gyro {
        name "gyro"
      }
      Accelerometer {
        name "accelerometer"
      }
''')
    s = s.replace("    children [\n      Shape {\n        appearance DEF grey", "    " + sensors + "      Shape {\n        appearance DEF grey", 1)

    # 4b. accelerometer at the coffee COM, inside the module Solid
    mod_children = re.search(r'(      Solid \{\n        translation 0\.000000 0\.000000 0\.089000\n        children \[\n)', s)
    if not mod_children:
        raise SystemExit("module Solid not found -- did the URDF change?")
    s = s.replace(mod_children.group(1), mod_children.group(1) +
                  f'''          Accelerometer {{
            translation 0 0 {Z_VASO}
            name "accel_vaso"
          }}
''', 1)

    # 5. contact materials
    for wheel in ("right_wheel", "left_wheel"):
        s = s.replace(f'          name "{wheel}"\n', f'          name "{wheel}"\n          contactMaterial "rueda"\n', 1)
    for ball in ("caster_front", "caster_back"):
        s = s.replace(f'        name "{ball}"\n', f'        name "{ball}"\n        contactMaterial "bola"\n', 1)

    # 6. module mesh shadows
    s = re.sub(r"(\n(\s*)geometry DEF Modulo_)", r"\n\2castShadows FALSE\1", s, count=1)

    checks = {
        "header": "# description:" in s,
        "controller": '"oak9_linea_recta"' in s,
        "imu": 'name "imu"' in s and 'name "gyro"' in s and 'name "accelerometer"' in s,
        "accel_vaso": 'name "accel_vaso"' in s,
        "rueda x2": s.count('contactMaterial "rueda"') == 2,
        "bola x2": s.count('contactMaterial "bola"') == 2,
        "castShadows": "castShadows FALSE" in s,
        "no backslash": "\\" not in "".join(re.findall(r'url "[^"]*"', s)),
    }
    bad = [k for k, ok in checks.items() if not ok]
    if bad:
        raise SystemExit(f"{path}: corrections NOT applied: {bad}")
    if s != n0:
        open(path, "w", encoding="utf-8", newline="\n").write(s)
    print(f"{path}: OK ({', '.join(checks)})")


if __name__ == "__main__":
    for p in sys.argv[1:]:
        fix(p)
