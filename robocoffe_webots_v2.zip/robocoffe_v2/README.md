# OAK9 + módulo de café en Webots (RoboCoffe, LabDST)

Hay dos simulaciones con el mismo robot, el mismo controlador y la misma trayectoria: o5 en línea recta de A = (0, 0) a B = (1, 0). Solo cambia el módulo: **sin café** y **con café**.

La estructura y el flujo siguen la presentación *Generación de PROTOs para Webots*: SolidWorks → STL → URDF → `urdf2webots` → PROTO corregido → Webots.

## Estructura

```
robocoffe_v2/
├── cad/                         STL y Data.txt tal como los exportó el equipo
├── urdf/
│   ├── oak9_sinCafe.urdf        6 links, 5 joints
│   └── oak9_conCafe.urdf        idéntico, salvo el link "modulo"
├── webots/                      proyecto de Webots
│   ├── controllers/oak9_linea_recta/oak9_linea_recta.py
│   ├── protos/Oak9_sinCafe.proto, Oak9_conCafe.proto   (urdf2webots + correcciones)
│   ├── protos/meshes/*.STL
│   └── worlds/oak9_sinCafe.wbt, oak9_conCafe.wbt
├── referencia/                  PROTOs tal cual los generó urdf2webots (sin corregir)
├── tools/
│   ├── calc_inercias.py         masas medidas + inercias desde las STL -> inertials.json
│   ├── generar_urdf.py          inertials.json -> los dos URDF
│   ├── corregir_proto.py        reaplica las correcciones a mano después de cada exportación
│   ├── comparar_corridas.py     figura y tabla sin café vs con café
│   └── resultados_prueba/       corrida de verificación (CSV + figura)
└── requirements.txt             el mismo del curso (urdf2webots 2025.0.0)
```

## Cómo correrlo

1. En Webots R2025a, abre `webots/worlds/oak9_sinCafe.wbt` y dale **Play**. Repite con `oak9_conCafe.wbt`.
2. Cada corrida guarda `webots/controllers/oak9_linea_recta/log_<caso>.csv`.
3. Con las dos corridas hechas, ejecuta desde la raíz del proyecto `python tools/comparar_corridas.py`. Genera la figura y la tabla.

La distancia se cambia en el `.wbt`, en `controllerArgs` → `"dist=1.0"`. Para que la comparación sea válida, usa la misma distancia en los dos mundos.

## Si cambian el CAD o las masas

```
python tools/calc_inercias.py          # edita primero las masas al inicio del archivo
python tools/generar_urdf.py
python -m urdf2webots.importer --input="urdf/oak9_sinCafe.urdf" --output="webots/protos/Oak9_sinCafe.proto"
python -m urdf2webots.importer --input="urdf/oak9_conCafe.urdf" --output="webots/protos/Oak9_conCafe.proto"
python tools/corregir_proto.py webots/protos/Oak9_sinCafe.proto webots/protos/Oak9_conCafe.proto
```

## Datos usados y decisiones

| Dato | Valor | Fuente |
|---|---|---|
| L (separación entre ruedas) | 0.1663 m | Ficha técnica (decisión del equipo, Data.txt) |
| ρ (radio de rueda) | 0.034 m | o_1.STL |
| Bolas locas | x = ±0.060 m, z = 0.005 m | Alojamientos medidos en o_0.STL |
| Altura del módulo | z = 0.089 m | Cara superior de o_0.STL |
| Robot sin módulo | 1.096 kg | Báscula |
| Ruedas | 0.098 kg c/u | SolidWorks (no se pudo desmontar la rueda) `<POR MEDIR>` |
| Chasis (base_link) | 0.8915 kg = 1.096 − 2 ruedas − 2 bolas | Calculado |
| Módulo vacío | 0.200 kg | Báscula |
| Vaso con café | 0.355 kg | Báscula; modelado como líquido que llena el vaso hasta 18 mm del borde |
| μ llanta–piso / bola–piso | 1.0 / 0.0 | `<POR MEDIR>` / bola que rueda libre |
| Aceleración de rueda | 10 rad/s² (0.34 m/s²) | `<POR MEDIR>` con `robot.encoder.kinematics()` en el robot real |

### Contradicciones encontradas en Data.txt

1. **Altura del módulo.** El texto dice "92.62 mm creo", pero la cara superior de `o_0.STL` está en **89.0 mm**. Con 92.62 el módulo quedaría flotando 3.6 mm sobre el chasis, así que se usó 89.0.
2. **Masa del robot.** Los 1096 g se pesaron **con ruedas**, pero en SolidWorks se asignaron solo al chasis. Si se dejaba así, el robot completo pesaría 1.30 kg en lugar de 1.096 kg. Se restaron las ruedas y las bolas.
3. **Masa del módulo con café.** En SolidWorks se puso **522 g**, pero la suma de lo medido en báscula es 200 + 355 = **555 g**. Se usó 555.
4. **Centro de masa con café.** SolidWorks reparte la masa uniformemente en todo el sólido y ubica el centro de masa en z = 57.7 mm. Pero el café (355 g) está dentro del vaso, mucho más arriba. Calculado por separado, el centro de masa queda en **z = 94.4 mm**. El del robot completo sube de 59.9 mm (sin café) a **91.4 mm** (con café).
5. **Inercias del módulo sin café.** Las que reporta Data.txt corresponden a la masa del material (~303 g), no a los 200 g asignados. Además, se calcularon con el sistema `-- default --` en lugar de `webots`. Se recalcularon desde la STL; el centro de masa coincide con el de SolidWorks.

## Correcciones a mano del PROTO (las aplica `tools/corregir_proto.py`)

- Rutas de malla con `/`.
- Encabezado con `tags`, `keywords` y `description`.
- `controller "oak9_linea_recta"` y nombre `"OAK9"`.
- `InertialUnit`, `Gyro` y `Accelerometer` en el chasis (la MPU6050).
- Un `Accelerometer` llamado `accel_vaso` en el centro de masa del café.
- `contactMaterial "rueda"` en las ruedas y `"bola"` en las bolas, para que el mundo les asigne fricciones distintas.
- `castShadows FALSE` en el módulo, porque tiene más de 21,845 triángulos.

## Verificación (resultados_prueba/)

Las dos simulaciones se corrieron en Webots R2025a sin interfaz gráfica, sobre un piso plano equivalente al `RectangleArena`.

| | t de llegada | x₅ final | desviación en y | cabeceo máx. | aceleración máx. en el vaso |
|---|---|---|---|---|---|
| Sin café | 11.27 s | 0.990 m | 0.00 mm | 0.000° | 0.34 m/s² |
| Con café | 11.27 s | 0.990 m | 0.00 mm | 0.000° | 0.34 m/s² |

El controlador es cinemático: comanda las mismas velocidades de rueda con o sin carga. El robot se apoya en 4 puntos rígidos (2 ruedas y 2 bolas), así que no cabecea. Incluso subiendo la aceleración de rueda a 400 rad/s², el cabeceo se mantuvo por debajo de 0.001° en los dos casos.

**Lo que sí cambia con el café son los márgenes.** Estas son estimaciones cuasiestáticas:

| Margen | Sin café | Con café |
|---|---|---|
| Aceleración para volcar sobre una bola (g·0.060/h_cm) | ≈ 9.8 m/s² | ≈ 6.4 m/s² |
| Aceleración para derramar (g · 18 mm / 38 mm de radio de la superficie) | — | ≈ 4.6 m/s² |

El chapoteo dinámico puede reducir el umbral de derrame. **Webots no simula líquidos**: el café está modelado como una masa rígida.

## Pendientes

- Masa real de la rueda; μ llanta–piso; aceleración real de rueda del firmware (`<POR MEDIR>`).
- Altura real del líquido en el vaso (`<POR MEDIR>`). Se supuso 355 ml.
